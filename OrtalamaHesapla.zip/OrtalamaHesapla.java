package exercises;

import java.util.Scanner;

public class OrtalamaHesapla {
	public static void main(String []args) {
		/*Java ile Matematik, Fizik, Kimya, Türkçe, Tarih, Müzik derslerinin 
		  sınav puanlarını kullanıcıdan alan ve ortalamalarını
		  hesaplayıp ekrana bastırılan programı yazın.
		 */
		Scanner input = new Scanner(System.in);
		System.out.print("Türkçe notunuzu giriniz:");
		double turkce = input.nextDouble() ;
		System.out.print("Matematik notunuzu giriniz:");
		double mat = input.nextDouble();
		System.out.print("Fizik notunuzu giriniz:");
		double fizik = input.nextDouble();
		System.out.print("Kimya notunuzu giriniz:");
		double kimya = input.nextDouble();
		System.out.print("Tarih notunuzu giriniz:");
		double tarih = input.nextDouble();
		System.out.println("Müzik notunuzu giriniz:");
		double müzik = input.nextDouble();
		double toplam = turkce + mat + fizik + kimya + tarih + müzik;
		double ortalama = toplam / 6;
		System.out.println("Ortalamanız:"+ ortalama);
	

		}
	}

